
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mtercero
 */
public class Book {
    private String bookName;
    private int isbn;
    private String bookAuthor;
    private String bookLocation;
    private String bookBorrower;
    private double price;
    private java.util.Date returnDate;
    private java.util.Date borrowDate;
    private String isBorrowed;
    
    public Book(String bookName, int isbn, String bookAuthor, String bookLocation, double price){
        
        this.bookName = bookName;
        this.isbn = isbn;
        this.bookAuthor = bookAuthor;
        this.bookLocation = bookLocation;
        this.price = price;
    }
    
    
    
    public Book(String selected) {
        this.bookLocation = selected;
        this.bookName = selected;
    }
    
    public Book(int bn, String bookBorrower, String borrowed, java.sql.Date borrowDate, java.sql.Date returnDate){
        this.isbn = bn;
        this.bookBorrower = bookBorrower;
        this.isBorrowed = borrowed;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

   
    Book(int selected) {
        this.isbn = selected;
    }

    Book(String libBookName, String libBookAuthor, int isbn, String libBookLocation) {
        this.bookName = libBookName;
        this.bookAuthor = libBookAuthor;
        this.isbn = isbn;
        this.bookLocation = libBookLocation;
    }

       
    
    
     public String getbookName(){
        return bookName;
    }
    
    public int getisbn(){
        return isbn;
    }
    public String getbookAuthor(){
        return bookAuthor;
    }
    public String getbookLocation(){
        return bookLocation;
    }
    public double getprice(){
        return price;
    }
    public String getbookBorrower(){
        return bookBorrower;
    }
    
    public Date getreturnDate(){
        return returnDate;
    }
    public Date getborrowDate(){
        return borrowDate;
    }
    
}
