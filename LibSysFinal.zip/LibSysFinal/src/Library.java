
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mtercero
 */
public class Library {
    private List<Book> collection;
    ArrayList<Book> loadLibAvail;
    private String libName;
    private String libAddress;
    private int id;
    ArrayList<Book> b = new ArrayList<>();
    private int totalNum;
    
    
    
//CONSTRUCTORS	
	public Library(){
		collection = new ArrayList<Book>();
               
		
	}
        
         public Library(int id) {
        this.id =id;
        
        }
        
        public Library (int id, String libName, String libAddres){
        this.id = id;
        this.libName = libName;
        this.libAddress = libAddress;
        
        
    }
        
//METHODS	
	public void addBook(Book book){
		//collection.add(book);
                   try
                    {
                      
                      // create a mysql database connection
                      String myDriver = "com.mysql.cj.jdbc.Driver";
                      String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
                      Class.forName(myDriver);
                      Connection conn = DriverManager.getConnection(myUrl, "root", "1234");

                      String query = "INSERT INTO libbooks (isbn, libBookName, libBookAuthor, libBookPrice, libBookLocation)"
                        + " values (?, ?, ?, ?, ?)";

                      // create the mysql insert preparedstatement
                      PreparedStatement preparedStmt = conn.prepareStatement(query);
                      preparedStmt.setInt (1, book.getisbn());
                      preparedStmt.setString (2, book.getbookName());
                      preparedStmt.setString (3, book.getbookAuthor());
                      preparedStmt.setDouble (4, book.getprice());
                      preparedStmt.setString (5, book.getbookLocation());


                      // execute the preparedstatement
                      preparedStmt.execute();




                      conn.close();
                      JOptionPane.showMessageDialog(null,"Book has been added.");

                    }catch (Exception e){
                      System.err.println("Got an exception!");
                      System.err.println(e.getMessage());
                      JOptionPane.showMessageDialog(null,e.getMessage());
                    }
          
	}
    
               
                
	
        public void updateBook(Book book){
            try
            {
              // create a mysql database connection
              String myDriver = "com.mysql.cj.jdbc.Driver";
              String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
              Class.forName(myDriver);
            try (Connection conn = DriverManager.getConnection(myUrl, "root", "1234")) {
                String query = "UPDATE libbooks SET libBookName= '" + book.getbookName() +"', libBookAuthor = '" + book.getbookAuthor() + "', " +
                        "libBookPrice = " +  book.getprice() + ", libBookLocation = '" + book.getbookLocation() + "' WHERE isbn = " + book.getisbn();
                
                // create the mysql insert preparedstatement
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                
                // execute the preparedstatement
                preparedStmt.execute();
                JOptionPane.showMessageDialog(null,"Book has been updated.");
            }

            }
    catch (ClassNotFoundException | SQLException e)
            {
              System.err.println("Got an exception!");
              System.err.println(e.getMessage());
              JOptionPane.showMessageDialog(null,e.getMessage());
            }
            
        }
         public void returnBook(Book book){
             try
            {
              // create a mysql database connection
              String myDriver = "com.mysql.cj.jdbc.Driver";
              String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
              Class.forName(myDriver);
              Connection conn = DriverManager.getConnection(myUrl, "root", "1234");

              String query = "DELETE FROM borrowedBooks WHERE isbn = " + book.getisbn();

              // create the mysql insert preparedstatement
              PreparedStatement preparedStmt = conn.prepareStatement(query);
                            // execute the preparedstatement
              preparedStmt.execute();




              conn.close();
              JOptionPane.showMessageDialog(null,"Book has been returned.");
              

            }
    catch (Exception e)
            {
              System.err.println("Got an exception!");
              System.err.println(e.getMessage());
              JOptionPane.showMessageDialog(null,e.getMessage());
            }
          
            
        }
        public void borrowBook(Book book){
            try
            {
              // create a mysql database connection
              String myDriver = "com.mysql.cj.jdbc.Driver";
              String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
              Class.forName(myDriver);
              Connection conn = DriverManager.getConnection(myUrl, "root", "1234");

              String query = "INSERT INTO borrowedBooks (isbn, borrowedDate, returnDate, borrowerBook, isBorrowed)"
                + " values (?, ?, ?, ?, ?)";

              // create the mysql insert preparedstatement
              PreparedStatement preparedStmt = conn.prepareStatement(query);
              preparedStmt.setInt (1, book.getisbn());
              preparedStmt.setDate (2, (Date) book.getborrowDate());
              preparedStmt.setDate (3, (Date) book.getreturnDate());
              preparedStmt.setString (4, book.getbookBorrower());
              preparedStmt.setString (5, "yes");


              // execute the preparedstatement
              preparedStmt.execute();




              conn.close();
              JOptionPane.showMessageDialog(null,"Book has been borrowed.");

            }catch (Exception e)
            {
              System.err.println("Got an exception!");
              System.err.println(e.getMessage());
              JOptionPane.showMessageDialog(null,e.getMessage());
            }
            
        }
        
        public void deleteBook(Book book){
            try
            {
              // create a mysql database connection
              String myDriver = "com.mysql.cj.jdbc.Driver";
              String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
              Class.forName(myDriver);
              Connection conn = DriverManager.getConnection(myUrl, "root", "1234");

              String query = "DELETE FROM libbooks WHERE isbn = " + book.getisbn();

              // create the mysql insert preparedstatement
              PreparedStatement preparedStmt = conn.prepareStatement(query);
                            // execute the preparedstatement
              preparedStmt.execute();




              conn.close();
              JOptionPane.showMessageDialog(null,"Book has been deleted.");
              

            }
    catch (Exception e)
            {
              System.err.println("Got an exception!");
              System.err.println(e.getMessage());
              JOptionPane.showMessageDialog(null,e.getMessage());
            }
          
            
        }
        
        
        
 public void addLibrary(int id, String libName, String libAddress){
 try {
      // create a mysql database connection
      String myDriver = "com.mysql.cj.jdbc.Driver";
      String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
      Class.forName(myDriver);
      Connection conn = DriverManager.getConnection(myUrl, "root", "1234");
   
      String query = "INSERT INTO libName (idLibName, libName, libAddress)"
        + " values (?, ?, ?)";

      // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = conn.prepareStatement(query);
      preparedStmt.setInt (1, id);
      preparedStmt.setString (2, libName);
      preparedStmt.setString (3, libAddress);
      

      // execute the preparedstatement
      preparedStmt.execute();
      
      
      
      
      conn.close();
      JOptionPane.showMessageDialog(null,"New library location has been added.");
      
    }catch (Exception e){
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
      JOptionPane.showMessageDialog(null,e.getMessage());
    }
          
    
    }
    public void showLibrary(){
        
        
    }
    
    public void deleteLibrary(int id){
          try
    {
      // create a mysql database connection
      String myDriver = "com.mysql.cj.jdbc.Driver";
      String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
      Class.forName(myDriver);
      Connection conn = DriverManager.getConnection(myUrl, "root", "1234");
   
      String query = "DELETE FROM libname WHERE idlibName = " + id;

      // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = conn.prepareStatement(query);
      // execute the preparedstatement
      preparedStmt.execute();
      
      
      
      
      conn.close();
      JOptionPane.showMessageDialog(null,"Library location has been deleted.");
      
    }
    catch (Exception e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
      JOptionPane.showMessageDialog(null,e.getMessage());
    }
          
    
    }
    public void updateLibrary(int idlibName, String libName, String libAddress) {
        try
            {
              // create a mysql database connection
              String myDriver = "com.mysql.cj.jdbc.Driver";
              String myUrl = "jdbc:mysql://localhost:3306/librarysystem";
              Class.forName(myDriver);
            try (Connection conn = DriverManager.getConnection(myUrl, "root", "1234")) {
                String query = "UPDATE libname SET libName= '" + libName +"', libAddress = '" + libAddress + "' " +
                       "WHERE idlibName = " + idlibName;
                
                // create the mysql insert preparedstatement
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                System.out.println(query);
                
                // execute the preparedstatement
                preparedStmt.execute();
                JOptionPane.showMessageDialog(null,"Library location has been updated.");
            }

            }
    catch (ClassNotFoundException | SQLException e)
            {
              System.err.println("Got an exception!");
              System.err.println(e.getMessage());
              JOptionPane.showMessageDialog(null,e.getMessage());
            }
    }
        
   
    //SHOW
    public ResultSet viewUnborrowedBooks(Book book){
        String selected = book.getbookLocation();
        Statement stmt;
        ResultSet rs = null;
           
    try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            java.sql.Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/librarysystem","root","1234");  
            //here sonoo is database name, root is username and password
            
             stmt=con.createStatement();  
   
             rs = stmt.executeQuery("SELECT libbooks.LIBBOOKNAME, libbooks.LIBBOOKAUTHOR,\n" +
                    "    libbooks.isbn, libbooks.libBookLocation\n" +
                    "    FROM\n" +
                    "        borrowedbooks RIGHT JOIN libbooks ON borrowedbooks.isbn = libbooks.isbn\n" +
                    "    WHERE borrowedbooks.isBorrowed is NULL AND libbooks.libBookLocation = '" + selected +"'");
    
        /*    Book books;
            while (rs.next()){
                books = new Book(rs.getString(1), rs.getString(2),rs.getInt(3), rs.getString(4));
                b.add(books);
            }
          */
         
            
          }catch(Exception e){ 
              System.out.println(e);
          }  
         return rs;

    }
    
    public ResultSet viewBorrowedBooks(Book book){
        String selected = book.getbookLocation();
        Statement stmt;
        ResultSet rs = null;
           
    try{  
           Class.forName("com.mysql.cj.jdbc.Driver");  
            java.sql.Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/librarysystem","root","1234");  
            //here sonoo is database name, root is username and password
            
            stmt=con.createStatement();  
   
            rs = stmt.executeQuery("SELECT libbooks.ISBN, libbooks.LIBBOOKNAME, libbooks.LIBBOOKAUTHOR,\n" +
                    "    borrowedBooks.borrowerBook, borrowedBooks.returnDate\n" +
                    "    FROM\n" +
                    "        borrowedBooks JOIN libbooks ON borrowedBooks.isbn = libbooks.isbn\n" +
                    "    WHERE borrowedBooks.isBorrowed = 'yes' AND libbooks.libBookLocation = '" + selected +"'");
    
        /*    Book books;
            while (rs.next()){
                books = new Book(rs.getString(1), rs.getString(2),rs.getInt(3), rs.getString(4));
                b.add(books);
            }
          */
         
            
          }catch(Exception e){ 
              System.out.println(e);
          }  
         return rs;

    }
    public ResultSet viewAllBooks(){
        
        Statement stmt;
        ResultSet rs = null;
           
    try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            java.sql.Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/librarysystem","root","1234");  
            //here sonoo is database name, root is username and password
            
             stmt=con.createStatement();  
   
             rs = stmt.executeQuery("SELECT * from libbooks");
    
        /*    Book books;
            while (rs.next()){
                books = new Book(rs.getString(1), rs.getString(2),rs.getInt(3), rs.getString(4));
                b.add(books);
            }
          */
         
            
          }catch(Exception e){ 
              System.out.println(e);
          }  
         return rs;

    }
    
    public ResultSet searchBooks(Book book){
        String selected = book.getbookName();
        Statement stmt;
        ResultSet rs = null;
           
    try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            java.sql.Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/librarysystem","root","1234");  
            //here sonoo is database name, root is username and password
             //String query = "SELECT * from libbooks where libBookName = '" + book.getbookName()+"'";
             stmt=con.createStatement();  
   
             rs = stmt.executeQuery("SELECT * from libbooks where libBookName LIKE '%" +selected+"%'");
             //System.out.println(query);
        /*    Book books;
            while (rs.next()){
                books = new Book(rs.getString(1), rs.getString(2),rs.getInt(3), rs.getString(4));
                b.add(books);
            }
          */
         
            
          }catch(Exception e){ 
              System.out.println(e);
          }  
         return rs;

    }
    /* public ArrayList<Book> getList(){
     return b;
        }*/
 
    
}
